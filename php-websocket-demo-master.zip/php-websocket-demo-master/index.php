<?php
require('SocketServer.php');
$socketServer = new SocketServer();
$socketServer->start();