window下运行的方法：
1.运行cmd
2.切换至程序根目录
3.执行命令php index.php
4.浏览器访问client.html

linux:
1.切换至程序根目录
2.执行php index.php
3.浏览器访问client.html

ps:如果代码放linux，window访问的话，记得修改防火墙及将ip改为linux的ip